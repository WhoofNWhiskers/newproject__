package com.example.newproject;

import java.io.Serializable;

public class Request implements Serializable {

    private String senderemail;
    private String receiveremail;
    private String message;
    private long timestamp;
    private String status;

    private String Id;
    private String SenderName;


    public Request() { }


    public Request(String senderemail, String receiveremail, String message, long timestamp, String status,String SenderName,String Id) {
        this.senderemail = senderemail;
        this.receiveremail = receiveremail;
        this.message = message;
        this.timestamp = timestamp;
        this.status = status;
        this.SenderName=SenderName;
        this.Id=Id;
    }

    public String getSenderemail() {
        return senderemail;
    }

    public void setSenderemail(String senderemail) {
        this.senderemail = senderemail;
    }

    public String getReceiveremail() {
        return receiveremail;
    }

    public void setReceiveremail(String receiveremail) {
        this.receiveremail = receiveremail;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSenderName() {
        return SenderName;
    }

    public void setSenderName(String senderName) {
        SenderName = senderName;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }
}