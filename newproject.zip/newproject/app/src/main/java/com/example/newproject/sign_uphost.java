package com.example.newproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.single.PermissionListener;

import java.util.HashMap;
import java.util.Map;

import static android.content.ContentValues.TAG;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.util.HashMap;
import java.util.Map;


public class sign_uphost extends AppCompatActivity {

    EditText email_host,Fname_host,Lname_host,pass_host,phone_host,address_host,additoonal;
    Button bt2;
    FirebaseFirestore db;
    FirebaseAuth mAuth;
    FirebaseDatabase data;
    SupportMapFragment mapFragment;
    FusedLocationProviderClient fusedLocationProviderClient;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_uphost);


        mAuth = FirebaseAuth.getInstance();
        db=FirebaseFirestore.getInstance();
        data=FirebaseDatabase.getInstance();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.googlemaps);
        fusedLocationProviderClient = (FusedLocationProviderClient) LocationServices.getFusedLocationProviderClient(this);
        Fname_host=findViewById(R.id.first_name_edit_text);
        Lname_host=findViewById(R.id.last_name_edit_text);
        email_host=findViewById(R.id.email_edit_text);
        pass_host=findViewById(R.id.password_edit_text);
        phone_host=findViewById(R.id.phone_edit_text);
        address_host=findViewById(R.id.address_edit_text);
        additoonal=findViewById(R.id.info_edit_text);
        bt2=findViewById(R.id.signup_button_host);



                Dexter.withContext(getApplicationContext())
                        .withPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                        .withListener(new PermissionListener() {
                            @Override
                            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                                getcurrentLocation();

                            }

                            @Override
                            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {

                            }

                            @Override
                            public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                                permissionToken.continuePermissionRequest();

                            }
                        }).check();




            }


    private void getcurrentLocation() {

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {


            return;
        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                mapFragment.getMapAsync(new OnMapReadyCallback() {
                    @Override
                    public void onMapReady(@NonNull GoogleMap googleMap) {
                        if (location != null) {
                            LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
                            MarkerOptions markerOptions = new MarkerOptions().position(latLng).title("currrent location");
                            googleMap.addMarker(markerOptions);
                            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
                            bt2.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    final String firstname1_host= Fname_host.getText().toString();
                                    final String seconedname1_host= Lname_host.getText().toString();
                                    final String email1_host= email_host.getText().toString();
                                    final String password_host=pass_host.getText().toString();
                                    final String phonenumber_host=phone_host.getText().toString();
                                    final String addresshost=address_host.getText().toString();
                                    final String addti=additoonal.getText().toString();


                                    String emailPattern1 = "[a-zA-Z0-9._-]+@[a-z]+\\.[a-z]+";
                                    String passwordPattern1 = "^(?=.*[0-9])(?=.*[a-zA-Z]).{6,}$";
                                    String namePattern1="([a-zA-Z]+|[a-zA-Z]+\\\\s[a-zA-Z]+)";
                                    //String PhonePattern="\"(05)\\\\d{8}\"";




                                    if(TextUtils.isEmpty(firstname1_host)){
                                        Fname_host.setError("First Name  Required");
                                        return;
                                    }
                                    if(!firstname1_host.matches(namePattern1)){
                                        Fname_host.setError("The name must consist of letters");
                                        return;
                                    }

                                    if(TextUtils.isEmpty(seconedname1_host)){
                                        Lname_host.setError("Last Name  Required");
                                        return;
                                    }


                                    if(!seconedname1_host.matches(namePattern1)){
                                        Lname_host.setError("The name must consist of letters");
                                        return;
                                    }

                                    if(TextUtils.isEmpty(email1_host)){
                                        email_host.setError("Email Required");

                                        return;
                                    }

                                    if (!email1_host.matches(emailPattern1)) {
                                        email_host.setError("Email Required With Right Format");
                                        return;
                                    }


                                    if(TextUtils.isEmpty(password_host)){
                                        pass_host.setError("Password  is Required ");
                                        return;
                                    }

                                    if(!password_host.matches(passwordPattern1)){
                                        pass_host.setError("the password format is at least 6 characters long ,at least one letter and at least one digit");
                                        return;
                                    }

                                    if(TextUtils.isEmpty(phonenumber_host)){
                                        phone_host.setError("Phone  is Required ");
                                        return;
                                    }



                                    //add data to real time data






                                    DatabaseReference myRef1 = data.getReference("host data");

                                    Map<String,Object> pethost =new HashMap<>();

                                    pethost.put("first_name",firstname1_host);
                                    pethost.put("last name",seconedname1_host);
                                    pethost.put("email",email1_host);
                                    pethost.put("password",password_host);
                                    pethost.put("phonenumber",phonenumber_host);
                                    pethost.put("address",addresshost);
                                    pethost.put("additional info",addti);
                                    pethost.put("latitude", location.getLatitude());
                                    pethost.put("longitude", location.getLongitude());

                                    myRef1.push().setValue(pethost);






                                    myRef1.addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot1) {
                                            // This method is called once with the initial value and again
                                            // whenever data at this location is updated.

                                            Map<String, Object> value = (Map<String, Object>) dataSnapshot1.getValue();
                                            Log.d(TAG, "Value is: " + value);


                                        }

                                        @Override
                                        public void onCancelled(DatabaseError error) {
                                            // Failed to read value
                                            Log.w(TAG, "Failed to read value.", error.toException());

                                        }
                                    });


                                    //authinntcation

                                    mAuth.createUserWithEmailAndPassword(email1_host, password_host)
                                            .addOnCompleteListener( new OnCompleteListener<AuthResult>() {
                                                @Override
                                                public void onComplete(@NonNull Task<AuthResult> task) {
                                                    if (task.isSuccessful()) {
                                                        // Sign up success, update UI with the signed-in user's information
                                                        FirebaseUser user = mAuth.getCurrentUser();
                                                        Toast.makeText(sign_uphost.this, "Authentication success.",
                                                                Toast.LENGTH_SHORT).show();

                                                    } else {
                                                        Toast.makeText(sign_uphost.this, "Authentication failed.",
                                                                Toast.LENGTH_SHORT).show();


                                                    }
                                                }
                                            });



                                    //firebase store
                                    Map<String,Object> pethost1 =new HashMap<>();
                                    pethost1.put("first name",firstname1_host);
                                    pethost1.put("last name",seconedname1_host);
                                    pethost1.put("email",email1_host);
                                    pethost1.put("password",password_host);
                                    pethost1.put("phonenumber",phonenumber_host);
                                    pethost1.put("address",addresshost);
                                    pethost1.put("additional info",addti);

                                    db.collection("host user")
                                            .add(pethost1)
                                            .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                                @Override
                                                public void onSuccess(DocumentReference documentReference) {
                                                    Toast.makeText(sign_uphost.this,"successful",Toast.LENGTH_SHORT).show();
                                                }
                                            }).addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull  Exception e) {
                                                    Toast.makeText(sign_uphost.this,"unsuccessful",Toast.LENGTH_SHORT).show();

                                                }
                                            });



                                    //savelocation(location.getLatitude(), location.getLongitude());
                                    Toast.makeText(sign_uphost.this, "location is saved", Toast.LENGTH_SHORT).show();

                                    startActivity(new Intent(sign_uphost.this, login_page.class));
                                    finish();






                                }
                            });

                        }else {
                            Toast.makeText(sign_uphost.this, "pleas enter app permition", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }

    private void retrieveLocation() {
        // Retrieve the user's location from the database or other storage mechanism
        // Here's an example of how you could retrieve the data from a Firebase Realtime Database:
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference ref = database.getReference("host data");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                    double latitude = (double) userSnapshot.child("latitude").getValue();
                    double longitude = (double) userSnapshot.child("longitude").getValue();

                    // Do something with the latitude and longitude values
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }


        });
    }
}