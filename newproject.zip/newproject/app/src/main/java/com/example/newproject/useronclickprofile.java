package com.example.newproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class useronclickprofile extends AppCompatActivity {
    TextView namenew,enmailnew;
    Button btt1 ,btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_useronclickprofile);

        namenew=findViewById(R.id.thenameofprofile);
        enmailnew=findViewById(R.id.theemailofprofile);
        btt1=findViewById(R.id.send_request);
        btn2=findViewById(R.id.previous);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(useronclickprofile.this, userlist.class));
                finish();

            }
        });
        btt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //0 startActivity(new Intent(useronclickprofile.this, host_req.class));
                Toast.makeText(useronclickprofile.this, "You sent a request.", Toast.LENGTH_SHORT).show();

                String senderEmail = FirebaseAuth.getInstance().getCurrentUser().getEmail();
                String receiverEmail = enmailnew.getText().toString();
                String senderName = FirebaseAuth.getInstance().getCurrentUser().getDisplayName(); // Get the sender name
                String message = "Hello, I would like to connect with you."; // Replace with the actual message
                DatabaseReference requestsRef = FirebaseDatabase.getInstance().getReference("requests");
                String requestId = requestsRef.push().getKey();
                Request request = new Request(senderEmail, receiverEmail, message, System.currentTimeMillis(), "pending",senderName,requestId);
                requestsRef.child(requestId).setValue(request);
                Toast.makeText(useronclickprofile.this, "Request sent!", Toast.LENGTH_SHORT).show();

            }
        });

        Bundle bundle=getIntent().getExtras();
        if(bundle!=null){
            namenew.setText(bundle.getString("first_name"));
            enmailnew.setText(bundle.getString("email"));


        }




    }
}