package com.example.newproject;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class myAdptaer extends RecyclerView.Adapter<myAdptaer.MyViewHolder >   {

    Context con;
    ArrayList<User> list;//any name its okay





    public myAdptaer(Context con, ArrayList<User> list) {
        this.con = con;
        this.list = list;
    }

    public myAdptaer(ArrayList<User> list) {


        this.list = list;


    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(con).inflate(R.layout.item,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        User u=list.get(position);
        holder.firstname.setText(u.getFirst_name());
        holder.Email.setText(u.getEmail());


        // Set click listener on item view
        holder.reccard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(con,useronclickprofile.class);
                //intent.putExtra("name",list.get(holder.getAdapterPosition()).getFirstname());
                intent.putExtra("first_name",list.get(holder.getAdapterPosition()).getFirst_name());
                intent.putExtra("email",list.get(holder.getAdapterPosition()).getEmail());



                con.startActivity(intent);

            }
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }



    public static class  MyViewHolder extends RecyclerView.ViewHolder{

        TextView Email,firstname;
        CardView reccard;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            firstname=itemView.findViewById(R.id.thenameofdata);
            Email=itemView.findViewById(R.id.theemailofdata);
            reccard=itemView.findViewById(R.id.item);


        }



    }

}